package Banking;

import java.time.LocalDate;

public class Username {
	String username;
	String email;
	String pass;
	String nama_nasabah;
	String alamat_nasabah;
	LocalDate tanggal_lahir_nasabah;
	char gender;
}