package Banking;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {
	Scanner scan = new Scanner (System.in);
	String url = "jdbc:mysql://localhost:3306/bankingdatabase";
	
	public Main(){	
		
		int menu;
		
		do
		{
			System.out.println("Welcome to GG Bank");
			System.out.println("------------------");
			System.out.println();
			
			System.out.println("1. Login");
			System.out.println("2. Register");
			System.out.println("0. Exit");
			System.out.print(">> ");
			
			do
			{
				menu = scan.nextInt();
				scan.nextLine();
			}
			while (menu < 0 || menu > 2);
			
			System.out.println();
			if (menu == 1)
			{
				loginPage();
			}
			
			else if (menu == 2)
			{
				String username;
				String email;
				String nama;
				String alamat;
				String tanggal_lahir;
				String gender;
				String password;
				String password2;
				int no_rekening = 0;
				int pin;
				int pin2;
				Double saldo;
				boolean valid = false;
				
				do
				{
					System.out.print("Masukkan username: ");
					username = scan.nextLine();
					
					System.out.print("Masukkan email [Diakhiri dengan @gmail.com]: ");
					email = scan.nextLine();
					
					if (username.isBlank() || email.isBlank()) System.out.println("Data tidak boleh kosong!");
					else if (!email.endsWith("@gmail.com") || email.length() <= 10) System.out.println("Format email salah!");
					else
					{
						try {
							Connection cn = DriverManager.getConnection(url, "root", "");
							Statement st = cn.createStatement();
							ResultSet rs = st.executeQuery("SELECT username, email FROM msusername");
							
							while (rs.next())
							{
								if (username.equals(rs.getString(1)))
								{
									valid = false;
									System.out.println("Username telah dipakai, gunakan username lainnya!");
									System.out.println();
									break;
								}
								
								else if (email.equals(rs.getString(2)))
								{
									valid = false;
									System.out.println("Email telah dipakai, gunakan email lainnya!");
									System.out.println();
									break;
								}
								valid = true;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
				while (!valid);
				
				System.out.println();
				do
				{
					System.out.print("Masukkan nama lengkap anda: ");
					nama = scan.nextLine();
					
					System.out.print("Masukkan alamat tempat tinggal anda: ");
					alamat = scan.nextLine();
					
					System.out.print("Masukkan tanggal lahir [yyyy-mm-dd]: ");
					tanggal_lahir = scan.nextLine();
					
					System.out.print("Masukkan gender anda [L / P]: ");
					gender = scan.nextLine();
					
					if (nama.contains("\\d") || nama.contains("[^a-zA-Z\s]")) System.out.println("Nama tidak sesuai dengan kriteria!");
					else if (gender.charAt(0) != 'L' && gender.charAt(0) != 'P') System.out.println("Inputan gender anda salah!");
					else if (nama.isBlank() || alamat.isBlank() || tanggal_lahir.isBlank()) System.out.println("Data tidak boleh kosong!");
					else
					{
						try {
				            LocalDate.parse(tanggal_lahir);
				            break;
				        } catch (DateTimeParseException e) {
				            System.out.println("Format tanggal lahir tidak valid! Harap masukkan dengan format yyyy-mm-dd.");
				        }
					}
				}
				while(true);
				
				System.out.println();
				do
				{
					System.out.print("Masukkan password [ >= 8 karakter, huruf dan angka ]: ");
					password = scan.nextLine(); 
					
					System.out.print("Masukkan konfirmasi password: ");
					password2 = scan.nextLine();
					
					if (password.length() < 8) System.out.println("Password harus terdiri atas 8 karakter / lebih!");
					else if (password.matches("[a-zA-Z]+") || password.matches("[0-9]+")) System.out.println("Password harus memiliki minimal 1 huruf dan 1 angka!");
					else if (password.contains("[^a-zA-Z0-9]")) System.out.println("Password harus hanya terdiri dari huruf dan angka!");
					else if (!password.equals(password2)) System.out.println("Konfirmasi password tidak sesuai dengan password yang diinput awal!");
					else break;
					
					System.out.println();
				}
				while (true);
				
				try {
					Connection cn = DriverManager.getConnection(url, "root", "");
					Statement st = cn.createStatement();
					ResultSet rs = st.executeQuery("SELECT no_rekening FROM msrekening");
					
					while (rs.next())
					{
						no_rekening = rs.getInt(1);
					}
					
					no_rekening++;
					
					cn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				System.out.println();
				System.out.println("Akun berhasil dibuat, silahkan lengkapi data berikut");
				
				do
				{
					System.out.print("Masukkan PIN untuk rekening anda [6 digit]: ");
					pin = scan.nextInt();
					scan.nextLine();
					
					if (pin < 100000 || pin > 999999) System.out.println("Pin harus berjumlah 6 digit!");
					else break;
				}
				while (true);
				
				System.out.println();
				
				do
				{
					System.out.println("Lakukan deposito awal untuk pengisian saldo terlebih dahulu");
					System.out.print("Jumlah nominal: ");
					saldo = scan.nextDouble();
					scan.nextLine();
					
					System.out.print("Masukkan PIN: ");
					pin2 = scan.nextInt();
					scan.nextLine();
					
					if (pin == pin2)
					{
						try {
							Connection cn = DriverManager.getConnection(url, "root", "");
							PreparedStatement ps = cn.prepareStatement
								("INSERT INTO msusername " +
								"VALUES (?, ?, ?, ?, ?, ?, ?)");
							ps.setString(1, username);
							ps.setString(2, email);
							ps.setString(3, password);
							ps.setString(4, nama);
							ps.setString(5, alamat);
							ps.setDate(6, Date.valueOf(LocalDate.parse(tanggal_lahir)));
							ps.setString(7, gender);
							
							ps.executeUpdate();
							cn.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						try {
							Connection cn = DriverManager.getConnection(url, "root", "");
							PreparedStatement ps = cn.prepareStatement
								("INSERT INTO msrekening " +
								"VALUES (?, ?, 0)");
							ps.setInt(1, no_rekening);
							ps.setInt(2, pin);
							
							ps.executeUpdate();
							cn.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						try {
							Connection cn = DriverManager.getConnection(url, "root", "");
							Statement st = cn.createStatement();
							ResultSet rs = st.executeQuery("SELECT id_transaksi FROM mstransaksi WHERE id_transaksi REGEXP '^DE[0-9]{3}'");
							
							String id_depo = "DE001";
							
							while (rs.next())
							{
								String formattedNum = String.format("%03d", Integer.parseInt(rs.getString(1).substring(2)) + 1);
								id_depo = "DE" + formattedNum;
							}
							
							PreparedStatement ps = cn.prepareStatement
								("INSERT INTO mstransaksi " +
								"VALUES (?, ? , ?)");
							ps.setString(1, id_depo);
							ps.setDouble(2, saldo);
							ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
							
							int rowsAffected = ps.executeUpdate();
							
							if (rowsAffected > 0)
							{
								ps = cn.prepareStatement
									("INSERT INTO transactionheader " +
									"VALUES (?, ?, ?)");
								ps.setInt(1, no_rekening);
								ps.setString(2, username);
								ps.setString(3, id_depo);
								
								int rowsAffected1 = ps.executeUpdate();
								
								if (rowsAffected1 > 0)
								{
									ps = cn.prepareStatement
										("UPDATE msrekening r " +
										"JOIN transactionheader th ON r.no_rekening = th.no_rekening " +
										"JOIN msusername u ON th.username = u.username " +		
										"SET r.jumlah_saldo = ? " +
										"WHERE u.username = ? ");
									ps.setDouble(1, saldo);
									ps.setString(2, username);
									
									int rowsAffected2 = ps.executeUpdate();
									
									if (rowsAffected2 > 0)
									{
										System.out.println("Transaksi berhasil!");
										System.out.println();
										
										break;
									}
									else System.out.println("Gagal transaksi!");
								}
								else System.out.println("Gagal transaksi!");
							}
							else System.out.println("Gagal transaksi!");
							
							cn.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					
					else
					{
						System.out.println("PIN salah");
						System.out.println();
					}
				}
				while (true);
				
				mainPage(username);
			}
		}
		while (menu != 0);
	}

	void loginPage()
	{
		String username; String password;
		boolean valid = false;
		
		do
		{
			System.out.print("Masukkan username: ");
			username = scan.nextLine();
			
			System.out.print("Masukkan password: ");
			password = scan.nextLine(); 
			
			try {
				Connection cn = DriverManager.getConnection(url, "root", "");
				Statement st = cn.createStatement();
				ResultSet rs = st.executeQuery("SELECT username, pass FROM msusername");
				
				while (rs.next())
				{
					if (username.equals(rs.getString(1)))
					{
						if (password.equals(rs.getString(2)))
						{
							valid = true;
							System.out.println();
							mainPage(username);
							System.out.println();
							break;
						}
					}
				}
				
				if (!valid)
				{
					System.out.println("Username atau Password salah, apakah ingin input lagi? [y/n]");
					System.out.print(">> ");
					String repeat = scan.nextLine();
					
					if (repeat.equals("n"))
					{
						cn.close();
						break;
					}
				}
				cn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		while (!valid);
	}
	
	void mainPage(String username)
	{
		Username user = new Username();
		Rekening rek = new Rekening();
		List<Transaction> listTransaction = new ArrayList<>();
		
		try {
			Connection cn = DriverManager.getConnection(url, "root", "");
			PreparedStatement ps = cn.prepareStatement("SELECT * FROM msusername WHERE username = ?");
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next())
			{
				user.username = rs.getString(1);
				user.email = rs.getString(2);
				user.pass = rs.getString(3);
				user.nama_nasabah = rs.getString(4);
				user.alamat_nasabah = rs.getString(5);
				user.tanggal_lahir_nasabah = rs.getDate(6).toLocalDate();
				user.gender = rs.getString(7).charAt(0);
			}
			
			cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			Connection cn = DriverManager.getConnection(url, "root", "");
			PreparedStatement ps = cn.prepareStatement
				("SELECT * FROM msrekening r " +
		        "JOIN transactionheader th ON r.no_rekening = th.no_rekening " +
		        "JOIN msusername u ON th.username = u.username " +
		        "WHERE u.username = ?");
			
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next())
			{
				rek.no_rekening = rs.getInt(1);
				rek.pin_rekening = rs.getInt(2);
				rek.jumlah_saldo = rs.getDouble(3);
			}
			
			cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			Connection cn = DriverManager.getConnection(url, "root", "");
			PreparedStatement ps = cn.prepareStatement
				("SELECT * FROM mstransaksi t " +
				"JOIN transactionheader th ON t.id_transaksi = th.id_transaksi " +
				"JOIN msusername u ON th.username = u.username " +
				"WHERE u.username = ?");
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next())
			{
				Transaction tr = new Transaction();
				
				tr.id_transaksi = rs.getString(1);
				tr.total_transaksi = rs.getDouble(2);
				tr.waktu = rs.getTimestamp(3).toLocalDateTime();
				
				listTransaction.add(tr);
			}
			
			cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		int menu;
		do
		{
			System.out.println("Selamat datang, " + user.nama_nasabah + "!");
			System.out.println("-----------------------------------");
			System.out.println();
			
			System.out.println("1. Cek Profil & Update Data");
			System.out.println("2. Cek Rekening / Lakukan Transaksi");
			System.out.println("0. Logout");
			System.out.print(">> ");
			
			do
			{
				menu = scan.nextInt();
				scan.nextLine();
			}
			while (menu < 0 || menu > 2);
			
			System.out.println();
			
			if (menu == 1)
			{
				String opt;
				
				System.out.println("Profil");
				System.out.println("------");
				System.out.println();
				
				System.out.println("Username: " + user.username);
				System.out.println("Email: " + user.email);
				System.out.println("Nama Lengkap: " + user.nama_nasabah);
				System.out.println("Alamat: " + user.alamat_nasabah);
				System.out.println("Tanggal Lahir: " + user.tanggal_lahir_nasabah);
				System.out.print("Gender: ");
				if(user.gender == 'L') System.out.println("Pria");
				else System.out.println("Wanita");
				System.out.println();
				
				System.out.println("Apakah anda ingin merubah data profil anda? [y/n]");
				System.out.print(">> ");
				opt = scan.nextLine();
				
				System.out.println();
				if (opt.equals("y"))
				{
					int opt2;
					
					System.out.println("Data manakah yang ingin dirubah?");
					System.out.println("1. Email");
					System.out.println("2. Password");
					System.out.println("3. PIN");
					System.out.println("0. Cancel");
					System.out.print(">> ");
					
					do
					{
						opt2 = scan.nextInt();
						scan.nextLine();
					}
					while (opt2 < 0 || opt2 > 3);
					
					String yakin;
					if (opt2 == 1)
					{
						String newEmail;
						
						do
						{
							System.out.print("Email baru (diakhiri dengan @gmail.com): ");
							newEmail = scan.nextLine();
						}
						while (!newEmail.endsWith("@gmail.com") || newEmail.length() <= 10);
						
						System.out.println("Apakah anda yakin untuk merubah email menjadi '" + newEmail + "'? [y/n]");
						System.out.print(">> ");
						yakin = scan.nextLine();
						
						if (yakin.equals("y"))
						{
							user.email = newEmail;
							
							try {
								Connection cn = DriverManager.getConnection(url, "root", "");
								PreparedStatement ps = cn.prepareStatement
									("UPDATE msusername " +
									"SET email = ? " +
									"WHERE username = ? ");
								ps.setString(1, newEmail);
								ps.setString(2, username);
								int rowsAffected = ps.executeUpdate();
								
								if (rowsAffected > 0) System.out.println("Update berhasil!");
								else System.out.println("Gagal mengupdate data!");
								
								cn.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						
						System.out.println();
					}
					
					else if (opt2 == 2)
					{
						String newPassword;
						
						do
						{
							System.out.print("Password baru (8 karakter): ");
							newPassword = scan.nextLine();
						}
						while (newPassword.length() < 8 || newPassword.matches("[a-zA-Z]+") || newPassword.matches("[0-9]+") || newPassword.contains("[^a-zA-Z0-9]"));
						
						
						System.out.println("Apakah anda yakin untuk merubah password menjadi '" + newPassword + "'? [y/n]");
						System.out.print(">> ");
						yakin = scan.nextLine();
						
						if (yakin.equals("y"))
						{
							user.pass = newPassword;
							
							try {
								Connection cn = DriverManager.getConnection(url, "root", "");
								PreparedStatement ps = cn.prepareStatement
									("UPDATE msusername " +
									"SET pass = ? " +
									"WHERE username = ? ");
								ps.setString(1, newPassword);
								ps.setString(2, username);
								int rowsAffected = ps.executeUpdate();
								
								if (rowsAffected > 0) System.out.println("Update berhasil!");
								else System.out.println("Gagal mengupdate data!");
								
								cn.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
							
							System.out.println();
						}
					}
					
					else if (opt2 == 3)
					{
						int newPIN;
						
						do
						{
							System.out.print("PIN baru [6 digit]: ");
							newPIN = scan.nextInt();
							scan.nextLine();
						}
						while (newPIN < 100000 || newPIN > 999999);
						
						System.out.println("Apakah anda yakin untuk merubah PIN menjadi '" + newPIN + "'? [y/n]");
						yakin = scan.nextLine();
						
						if (yakin.equals("y"))
						{
							rek.pin_rekening = newPIN;
							try {
								Connection cn = DriverManager.getConnection(url, "root", "");
								PreparedStatement ps = cn.prepareStatement
									("UPDATE msrekening r " +
									"JOIN transactionheader th ON r.no_rekening = th.no_rekening " +
									"JOIN msusername u ON th.username = u.username " +
									"SET r.pin_rekening = ? " +
									"WHERE u.username = ? ");
								ps.setInt(1, newPIN);
								ps.setString(2, username);
								int rowsAffected = ps.executeUpdate();
								
								if (rowsAffected > 0) System.out.println("Update berhasil!");
								else System.out.println("Gagal mengupdate data!");
								
								cn.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
							
							System.out.println();
						}
					}
				}
			}
			
			else if (menu == 2)
			{
				String opt;
				
				System.out.println("Rekening");
				System.out.println("--------");
				System.out.println();
				
				System.out.println("Nomor Rekening: " + rek.no_rekening);
				Locale indonesia = new Locale("id", "ID");
		        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(indonesia);
				System.out.println("Jumlah Saldo: " + currencyFormat.format(rek.jumlah_saldo));
				
				System.out.println("Apakah anda ingin melakukan transaksi? [y/n]");
				System.out.print(">> ");
				opt = scan.nextLine();
				
				System.out.println();
				if (opt.equals("y"))
				{
					int opt2;
					
					System.out.println("Transaksi");
					System.out.println("---------");
					System.out.println();
					
					System.out.println("1. Withdraw");
					System.out.println("2. Deposit");
					System.out.println("3. Transfer");
					System.out.println("4. Rekaman Transaksi");
					System.out.println("0. Cancel");
					System.out.print(">> ");
					
					do
					{
						opt2 = scan.nextInt();
						scan.nextLine();
					}
					while (opt2 < 0 || opt2 > 4);
					
					if (opt2 == 1)
					{
						System.out.println("Withdraw");
						System.out.println("--------");
						System.out.println();
						
						Double saldo;
						
						System.out.print("Jumlah nominal: ");
						saldo = scan.nextDouble();
						scan.nextLine();
						
						if (rek.jumlah_saldo - saldo < 0)
						{
							System.out.println("Saldo tidak mencukupi!");
							System.out.println();
							break;
						}
						
						int pin;
						
						System.out.print("Masukkan PIN: ");
						pin = scan.nextInt();
						scan.nextLine();
						
						if (pin == rek.pin_rekening)
						{
							try {
								Connection cn = DriverManager.getConnection(url, "root", "");
								Statement st = cn.createStatement();
								ResultSet rs = st.executeQuery("SELECT id_transaksi FROM mstransaksi WHERE id_transaksi REGEXP '^WI[0-9]{3}'");
								
								String id_with = "WI001";
								
								while (rs.next())
								{
									String formattedNum = String.format("%03d", Integer.parseInt(rs.getString(1).substring(2)) + 1);
									id_with = "WI" + formattedNum;
								}
								
								Transaction tr = new Transaction();
								tr.id_transaksi = id_with;
								tr.total_transaksi = saldo;
								tr.waktu = LocalDateTime.now();
								
								
								PreparedStatement ps = cn.prepareStatement
									("INSERT INTO mstransaksi " +
									"VALUES (?, ? , ?)");
								ps.setString(1, tr.id_transaksi);
								ps.setDouble(2, tr.total_transaksi);
								ps.setTimestamp(3, Timestamp.valueOf(tr.waktu));
								
								int rowsAffected = ps.executeUpdate();
								
								if (rowsAffected > 0)
								{
									ps = cn.prepareStatement
										("INSERT INTO transactionheader " +
										"VALUES (?, ?, ?)");
									ps.setInt(1, rek.no_rekening);
									ps.setString(2, user.username);
									ps.setString(3, tr.id_transaksi);
									
									int rowsAffected1 = ps.executeUpdate();
									
									if (rowsAffected1 > 0)
									{
										ps = cn.prepareStatement
											("UPDATE msrekening r " +
											"JOIN transactionheader th ON r.no_rekening = th.no_rekening " +
											"JOIN msusername u ON th.username = u.username " +		
											"SET r.jumlah_saldo = ? " +
											"WHERE u.username = ? ");
										ps.setDouble(1, rek.jumlah_saldo - saldo);
										ps.setString(2, username);
										
										int rowsAffected2 = ps.executeUpdate();
										
										if (rowsAffected2 > 0)
										{
											rek.jumlah_saldo -= saldo;
											System.out.println("Transaksi berhasil!");
											System.out.println();
											listTransaction.add(tr);
										}
										else System.out.println("Gagal transaksi!");
									}
									else System.out.println("Gagal transaksi!");
								}
								else System.out.println("Gagal transaksi!");
								
								cn.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						
						else
						{
							System.out.println("PIN salah");
							System.out.println();
						}
					}
					
					else if (opt2 == 2)
					{
						System.out.println("Deposito");
						System.out.println("--------");
						System.out.println();
						
						Double saldo;
						
						System.out.print("Jumlah nominal: ");
						saldo = scan.nextDouble();
						scan.nextLine();
						
						int pin;
						
						System.out.print("Masukkan PIN: ");
						pin = scan.nextInt();
						scan.nextLine();
						
						if (pin == rek.pin_rekening)
						{
							try {
								Connection cn = DriverManager.getConnection(url, "root", "");
								Statement st = cn.createStatement();
								ResultSet rs = st.executeQuery("SELECT id_transaksi FROM mstransaksi WHERE id_transaksi REGEXP '^DE[0-9]{3}'");
								
								String id_depo = "DE001";
								
								while (rs.next())
								{
									String formattedNum = String.format("%03d", Integer.parseInt(rs.getString(1).substring(2)) + 1);
									id_depo = "DE" + formattedNum;
								}
								
								Transaction tr = new Transaction();
								tr.id_transaksi = id_depo;
								tr.total_transaksi = saldo;
								tr.waktu = LocalDateTime.now();
								
								
								PreparedStatement ps = cn.prepareStatement
									("INSERT INTO mstransaksi " +
									"VALUES (?, ? , ?)");
								ps.setString(1, tr.id_transaksi);
								ps.setDouble(2, tr.total_transaksi);
								ps.setTimestamp(3, Timestamp.valueOf(tr.waktu));
								
								int rowsAffected = ps.executeUpdate();
								
								if (rowsAffected > 0)
								{
									ps = cn.prepareStatement
										("INSERT INTO transactionheader " +
										"VALUES (?, ?, ?)");
									ps.setInt(1, rek.no_rekening);
									ps.setString(2, user.username);
									ps.setString(3, tr.id_transaksi);
									
									int rowsAffected1 = ps.executeUpdate();
									
									if (rowsAffected1 > 0)
									{
										ps = cn.prepareStatement
											("UPDATE msrekening r " +
											"JOIN transactionheader th ON r.no_rekening = th.no_rekening " +
											"JOIN msusername u ON th.username = u.username " +		
											"SET r.jumlah_saldo = ? " +
											"WHERE u.username = ? ");
										ps.setDouble(1, rek.jumlah_saldo + saldo);
										ps.setString(2, username);
										
										int rowsAffected2 = ps.executeUpdate();
										
										if (rowsAffected2 > 0)
										{
											rek.jumlah_saldo += saldo;
											System.out.println("Transaksi berhasil!");
											System.out.println();
											listTransaction.add(tr);
										}
										else System.out.println("Gagal transaksi!");
									}
									else System.out.println("Gagal transaksi!");
								}
								else System.out.println("Gagal transaksi!");
								
								cn.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						
						else
						{
							System.out.println("PIN salah");
							System.out.println();
						}
					}
					
					else if (opt2 == 3)
					{
						int noTujuan;
						String yakin;
						Double saldo;
						
						System.out.println("Transfer");
						System.out.println("--------");
						System.out.println();
						
						System.out.print("Nomor Rekening Tujuan: ");
						noTujuan = scan.nextInt();
						scan.nextLine();
						
						System.out.print("Jumlah nominal: ");
						saldo = scan.nextDouble();
						scan.nextLine();
						
						if (rek.jumlah_saldo - saldo < 0)
						{
							System.out.println("Saldo tidak mencukupi!");
							System.out.println();
						}
						
						else
						{
							boolean found = false;
							try {
								Connection cn = DriverManager.getConnection(url, "root", "");
								Statement s = cn.createStatement();
								ResultSet rs = s.executeQuery("SELECT no_rekening FROM msrekening");
								
								while (rs.next())
								{
									if (rs.getInt(1) == noTujuan)
									{
										System.out.println("Apakah anda yakin untuk mentransfer ke '" + noTujuan + "' dengan jumlah sebesar " + currencyFormat.format(saldo) + "? [y/n]");
										System.out.print(">> ");
										yakin = scan.nextLine();
										
										if (yakin.equals("y"))
										{
											found = true;
											int pin;
										
											System.out.print("Masukkan PIN: ");
											pin = scan.nextInt();
											scan.nextLine();
											
											if (pin == rek.pin_rekening)
											{
												try {
													Connection cn1 = DriverManager.getConnection(url, "root", "");
													Statement s1 = cn1.createStatement();
													ResultSet rs1 = s1.executeQuery("SELECT id_transaksi FROM mstransaksi WHERE id_transaksi REGEXP '^TR[0-9]{3}'");
													
													String id_trans = "TR001";
													
													while (rs1.next())
													{
														String formattedNum = String.format("%03d", Integer.parseInt(rs1.getString(1).substring(2)) + 1);
														id_trans = "TR" + formattedNum;
													}
													
													Transaction tr = new Transaction();
													tr.id_transaksi = id_trans;
													tr.total_transaksi = saldo;
													tr.waktu = LocalDateTime.now();
													
													PreparedStatement ps = cn.prepareStatement
														("INSERT INTO mstransaksi " +
														"VALUES (?, ?, ?)");
													ps.setString(1, tr.id_transaksi);
													ps.setDouble(2, tr.total_transaksi);
													ps.setTimestamp(3, Timestamp.valueOf(tr.waktu));
													
													int rowsAffected = ps.executeUpdate();
													
													if (rowsAffected > 0)
													{
														ps = cn.prepareStatement
															("INSERT INTO transactionheader " +
															"VALUES (?, ?, ?)");
														ps.setInt(1, rek.no_rekening);
														ps.setString(2, user.username);
														ps.setString(3, tr.id_transaksi);
														
														int rowsAffected1 = ps.executeUpdate();
														
														if (rowsAffected1 > 0)
														{
															ps = cn.prepareStatement
																("UPDATE msrekening r " +
																"JOIN transactionheader th ON r.no_rekening = th.no_rekening " +
																"JOIN msusername u ON th.username = u.username " +		
																"SET r.jumlah_saldo = ? " +
																"WHERE u.username = ? ");
															ps.setDouble(1, rek.jumlah_saldo - saldo);
															ps.setString(2, username);
															
															int rowsAffected2 = ps.executeUpdate();
															
															if (rowsAffected2 > 0)
															{
																ps = cn.prepareStatement
																	("UPDATE msrekening " +
																	"SET jumlah_saldo = jumlah_saldo + ? " +
																	"WHERE no_rekening = ? ");
																ps.setDouble(1, saldo);
																ps.setInt(2, noTujuan);
																ps.executeUpdate();
																
																rek.jumlah_saldo -= saldo;
																System.out.println("Transaksi berhasil!");
																System.out.println();
																listTransaction.add(tr);
															}
															else System.out.println("Gagal transaksi!");
														}
														else System.out.println("Gagal transaksi!");
													}
													else System.out.println("Gagal transaksi!");
													
													cn1.close();
												} catch (Exception e) {
													e.printStackTrace();
												}
											}
											
											else
											{
												System.out.println("PIN salah");
												System.out.println();
											}
										}
										
										break;
									}
								}
								
								if (!found)
								{
									System.out.println("Nomor rekening tidak ditemukan!");
									System.out.println();
								}
								
								cn.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
					
					else if (opt2 == 4)
					{
						System.out.println();
						if (!listTransaction.isEmpty())
						{
							System.out.printf(" %-15s | %-17s | %-19s | Keterangan\n", "ID Transaksi", "Nominal", "Waktu Transaksi");
							System.out.println(" ----------------------------------------------------------------------- ");
							DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
							for(Transaction temp : listTransaction)
							{
								System.out.printf(" %-15s | %-17s | %-19s | ", temp.id_transaksi, currencyFormat.format(temp.total_transaksi),temp.waktu.format(formatter));
								
								if (temp.id_transaksi.charAt(0) == 'D') System.out.println("Deposito");
								else if (temp.id_transaksi.charAt(0) == 'W') System.out.println("Withdraw");
								else System.out.println("Transfer");
							}
							
							System.out.println(" ----------------------------------------------------------------------- ");
							System.out.println();
						}
						
						else
						{
							System.out.println("Belum ada transaksi di rekening ini!");
							System.out.println();
						}
					}
				}
			}
		}
		while (menu != 0);
	}
	
	public static void main(String[] args){
		new Main();
	}
}