package Banking;

public class Rekening {
	int no_rekening;
	int pin_rekening;
	double jumlah_saldo;
}