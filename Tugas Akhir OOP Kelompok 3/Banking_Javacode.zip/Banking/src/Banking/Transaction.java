package Banking;

import java.time.LocalDateTime;

public class Transaction {
	String id_transaksi;
	double total_transaksi;
	LocalDateTime waktu;
}
